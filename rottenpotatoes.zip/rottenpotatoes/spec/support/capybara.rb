require 'capybara/rails'
require 'capybara/rspec'
